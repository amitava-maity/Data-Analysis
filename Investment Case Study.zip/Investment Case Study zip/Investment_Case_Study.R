
################# Checkpoint 1 ############################
#Load company data in a data frame using below parameters:
#1. sep - TAB is a column separator in file
#2. header - first row in file specifies column headers
#3. fill - fill blanks in case values in some rows are missing
#4. na.strings - empty values are considered as NA

company <- read.delim("companies.txt",header = TRUE,  sep = "\t",stringsAsFactors = FALSE)
rounds2 <- read.csv("rounds2.csv",header = TRUE,stringsAsFactors = FALSE)

#Loading complete 

#finding unique keys. coverting permalink to lower case in both dataset.

rounds2$permalink <- tolower(rounds2$company_permalink)
company$permalink <- tolower(company$permalink)

#finding unique companies present in company data frame and rounds2 dataframe

unique_companies <- unique(company[,"permalink"])
unique_rounds2_companies <- unique(rounds2[,"permalink"])

a <- unique_companies
b <- unique_rounds2_companies

c <- setdiff(b,a)

#merging both the files rounds2 and company in a single file based on permalink.
#New file will contain all records form rounds2

master_frame <- merge(rounds2, company,by = "permalink",all.rounds2=T)

#removing the records that dont have funding dollar information.

master_frame <- master_frame[!is.na(master_frame$raised_amount_usd),]

#performing funding type wise average
funding_type_average <- aggregate(master_frame$raised_amount_usd, by=list(master_frame$funding_round_type), FUN=mean,na.rm=TRUE)

#Average funding amount of venture type	          11748701.6                        
#Average funding amount of angel type	            958891.8
#Average funding amount of seed type	            719803.7 
#Average funding amount of private equity type	  73308593.0
#Considering that Spark Funds wants to invest between 5 to 15 million USD per investment round, which investment type is the most suitable for it?
#Venture
#fund type most suitable for spary fund is venture type
##################### Checkpoint 2 #########################
# Average funding amount of venture type

master_frame_1 <- filter(master_frame, funding_round_type == "venture")
View(master_frame_1)

#grouping of data based on country code to find sum for each countries

master_frame_1_group <- group_by(master_frame_1,country_code)

#find out sum of investment for each country

master_frame_1_group_summ <- summarise(master_frame_1_group, sum(raised_amount_usd, na.rm = T))

#arranging the data in decending order of sum of investment dollar

master_frame_1_group_summ_arranged <- arrange(master_frame_1_group_summ, desc(master_frame_1_group_summ$`sum(raised_amount_usd, na.rm = T)`))

#removing the data for which country is mentioned as blank

master_frame_1_group_summ_arranged <- master_frame_1_group_summ_arranged[!master_frame_1_group_summ_arranged$country_code == "",]

###################### Checkpoint 3 #######################

# Top 9 countries with highest total funding

top9 <- head(master_frame_1_group_summ_arranged,9)

#top three countris are USA, CHAINA AND GBR. But as we are only interested in english speaking countries top three country will be USA,GBR and IND

#  1. Top English-speaking country	 USA              
#2. Second English-speaking country	 GBR
#3. Third English-speaking country	 IND

library(dplyr)
library(tidyr)

# sector analysis: as catagory list is the colums we are interested. Remove the records with blank in catagory list column.

master_frame <- master_frame[!master_frame$category_list=="", ]

##################### Checkpoint 4 ########################
#Map category list to primary sector
# Read mapping file

#split catagory list by "|" to get the primary sector.

master_frame_sep <- separate(master_frame, category_list,into=c("category_list"),sep="[|]",remove = F)

#load mapping file to get the sector data.

mapping <- read.csv("mapping.csv")

#convert the mapping data in long format

mapping_long <- gather(mapping,main_sector,main_sector_val,Automotive...Sports:Social..Finance..Analytics..Advertising)
mapping_long <- mapping_long[!(mapping_long$main_sector_val == 0), ]
mapping_long <- mapping_long[, -3]

#merge mapping with master_frame to get consolidated frame with main sector

master_frame_sep_mer <- merge(master_frame_sep , mapping_long, by="category_list")
#checkpoint 4 meet

############################ Checkpoint 5 #################

# Three data frames corresponding to countries with investments for 

# All rows for country USA satisfying a condition

D1 <- filter(master_frame_sep_mer, master_frame_sep_mer$funding_round_type == "venture",master_frame_sep_mer$country_code == "USA")
D1 <- D1[!(D1$category_list == ""), ]

#total amount invested for USA

summarise(D1, sum(raised_amount_usd,na.rm=T))
D1 <- group_by(D1, main_sector)

#add sum of investment for every main sector and count of investment for every main sector

D1 <- mutate(D1, amt_invested_main_sector = sum(raised_amount_usd, na.rm = T))
D1 <- mutate(D1, count_investmet_main_sec = (total.count=n()))

#get filtered data frame for venture sector and top country i.e. GBR

D2 <- filter(master_frame_sep_mer, master_frame_sep_mer$funding_round_type == "venture",master_frame_sep_mer$country_code == "GBR")
D2 <- D2[!(D2$category_list == ""), ]

#total amount invested for GBR

summarise(D2, sum(raised_amount_usd,na.rm=T))
#add sum of investment for every main sector and count of investment for every main sector

D2 <- group_by(D2, main_sector)
D2 <- mutate(D2, amt_invested_main_sector = sum(raised_amount_usd, na.rm = T))
D2 <- mutate(D2, count_investmet_main_sec = (total.count=n()))

#get filtered data frame for venture sector and top country i.e. IND

D3 <- filter(master_frame_sep_mer, master_frame_sep_mer$funding_round_type == "venture",master_frame_sep_mer$country_code == "IND")
D3 <- D3[!(D3$category_list == ""), ]

#total amount invested for IND

summarise(D3, sum(raised_amount_usd,na.rm=T))
#add sum of investment for every main sector and count of investment for every main sector

D3 <- group_by(D3, main_sector)
D3 <- mutate(D3, amt_invested_main_sector = sum(raised_amount_usd, na.rm = T))
D3 <- mutate(D3, count_investmet_main_sec = (total.count=n()))

#checkpoint 5 answers

#code for deciding the top three sector in each country based on no of investment and their investment.

arrange(summarise(D1, total.count=n()),desc(total.count))
arrange(summarise(D2, total.count=n()),desc(total.count))
arrange(summarise(D3, total.count=n()),desc(total.count))

# FOR USA

D1A <- subset(D1,D1$main_sector == "Others")
D1a <- arrange(D1A, desc(raised_amount_usd))
D1a[1,2] 

D1A <- subset(D1, D1$main_sector == "Cleantech...Semiconductors")
D1a <- arrange(D1A, desc(raised_amount_usd))
D1a[1,2] 

# FOR GBR

D2A <- subset(D2,D2$main_sector == "Others")
D2a <- arrange(D2A, desc(raised_amount_usd))
D2a[1,2] 

D2A <- subset(D2, D2$main_sector == "Cleantech...Semiconductors")
D2a <- arrange(D2A, desc(raised_amount_usd))
D2a[1,2] 

# FOR IND

D3A <- subset(D3,D3$main_sector == "Others")
D3a <- arrange(D3A, desc(raised_amount_usd))
D3a[1,2]

D3A <- subset(D3, D3$main_sector == "News..Search.and.Messaging")
D3a <- arrange(D3A, desc(raised_amount_usd))
D3a[1,2] 

#exporting data for tableu plot

write.table(master_frame_sep_mer,"master_frame_SM.csv",sep = ",",row.names = F)

#reading country code file for deciding the plot
#country <- read.csv("country.csv",header = TRUE,stringsAsFactors = FALSE)
#exporting data for tableu plot
#master_frame_country <- merge(master_frame_sep_mer,country, by = "country_code")
#write.table(master_frame_country,"master_frame_cc.csv",sep = ",",row.names = F)
